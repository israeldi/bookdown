# 506_Project (Group 21)
This is the public repo for group project in STATS 506 at Umich

To-do list: 
Finish Rmarkdown file 